/*
 * Design: 「里山ブルワリー」— 和モダン・ナチュラルデザイン
 * Colors: 和紙ベージュ(#FAF6F0), 若葉色, 琥珀色, 墨色, 朱色
 * Typography: Zen Maru Gothic (headings), Noto Sans JP (body)
 * Layout: 巻物型縦スクロール、各セクションが独立した「章」
 */

import { useState, useEffect, useRef } from "react";
import { motion, useInView } from "framer-motion";
import { IMAGES } from "@/lib/images";
import { hopVarieties, beerStyles, brewingSteps } from "@/lib/data";
import type { HopVariety, BeerStyle } from "@/lib/data";
import { allQuizQuestions, QUIZ_THEMES } from "@/lib/quizData";
import type { QuizQuestion } from "@/lib/quizData";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Beer, Leaf, FlaskConical, BookOpen, HelpCircle, ChevronDown, ChevronRight, Check, X, MapPin, Thermometer, Droplets, Sun, Calendar, Lock, Unlock, Shuffle, RotateCcw, Trophy, Star, Zap, Target, Crown, Flame } from "lucide-react";

// ===== Animation wrapper =====
function FadeInSection({ children, className = "", delay = 0 }: { children: React.ReactNode; className?: string; delay?: number }) {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-80px" });
  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 40 }}
      animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 40 }}
      transition={{ duration: 0.7, delay, ease: "easeOut" }}
      className={className}
    >
      {children}
    </motion.div>
  );
}

// ===== Navigation =====
function Navigation() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 60);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const navItems = [
    { href: "#hop-types", label: "ホップの種類", icon: <Leaf className="w-4 h-4" /> },
    { href: "#beer-styles", label: "ビールの種類", icon: <Beer className="w-4 h-4" /> },
    { href: "#brewing", label: "醸造ガイド", icon: <FlaskConical className="w-4 h-4" /> },
    { href: "#chiba", label: "千葉で育てる", icon: <MapPin className="w-4 h-4" /> },
    { href: "#quiz", label: "クイズ", icon: <HelpCircle className="w-4 h-4" /> },
  ];

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${isScrolled ? "bg-[#FAF6F0]/95 backdrop-blur-md shadow-sm" : "bg-transparent"}`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <a href="#" className={`font-bold text-lg transition-colors ${isScrolled ? "text-[#2B2B2B]" : "text-white"}`} style={{ fontFamily: "'Zen Maru Gothic', sans-serif" }}>
            🍺 ホップ栽培ガイド
          </a>
          <div className="hidden md:flex items-center gap-1">
            {navItems.map((item) => (
              <a
                key={item.href}
                href={item.href}
                className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-sm font-medium transition-all ${
                  isScrolled
                    ? "text-[#2B2B2B]/70 hover:text-[#2B2B2B] hover:bg-[#69B076]/10"
                    : "text-white/80 hover:text-white hover:bg-white/10"
                }`}
              >
                {item.icon}
                {item.label}
              </a>
            ))}
          </div>
          <button
            onClick={() => setMobileOpen(!mobileOpen)}
            className={`md:hidden p-2 rounded-lg ${isScrolled ? "text-[#2B2B2B]" : "text-white"}`}
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              {mobileOpen ? <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /> : <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />}
            </svg>
          </button>
        </div>
      </div>
      {mobileOpen && (
        <div className="md:hidden bg-[#FAF6F0]/98 backdrop-blur-md border-t border-[#69B076]/20">
          {navItems.map((item) => (
            <a
              key={item.href}
              href={item.href}
              onClick={() => setMobileOpen(false)}
              className="flex items-center gap-2 px-6 py-3 text-[#2B2B2B]/80 hover:text-[#2B2B2B] hover:bg-[#69B076]/10"
            >
              {item.icon}
              {item.label}
            </a>
          ))}
        </div>
      )}
    </nav>
  );
}

// ===== Hero Section =====
function HeroSection() {
  return (
    <section className="relative h-screen flex items-center justify-center overflow-hidden">
      <div className="absolute inset-0">
        <img src={IMAGES.heroHopField} alt="ホップ畑" className="w-full h-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-b from-black/50 via-black/30 to-[#FAF6F0]" />
      </div>
      <div className="relative z-10 text-center px-4 max-w-4xl">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.3 }}
        >
          <p className="text-white/80 text-sm tracking-[0.3em] mb-4 uppercase" style={{ fontFamily: "'DM Sans', sans-serif" }}>
            Hop Growing Guide — Northern Chiba
          </p>
          <h1 className="text-4xl sm:text-5xl md:text-7xl font-bold text-white mb-6 leading-tight" style={{ fontFamily: "'Zen Maru Gothic', sans-serif" }}>
            千葉県北部で<br />ホップを育てよう
          </h1>
          <p className="text-white/90 text-lg sm:text-xl mb-10 max-w-2xl mx-auto leading-relaxed">
            ホップの種類から醸造の全工程まで。<br className="hidden sm:block" />
            自分だけのクラフトビールへの第一歩。
          </p>
          <a
            href="#hop-types"
            className="inline-flex items-center gap-2 bg-[#69B076] hover:bg-[#5A9A66] text-white px-8 py-4 rounded-full text-lg font-medium transition-all shadow-lg hover:shadow-xl"
          >
            学びを始める
            <ChevronDown className="w-5 h-5 animate-bounce" />
          </a>
        </motion.div>
      </div>
    </section>
  );
}

// ===== Hop Types Section =====
function HopTypesSection() {
  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  const [selectedHop, setSelectedHop] = useState<HopVariety | null>(null);

  const categories = ["all", "ファインアロマ", "アロマ", "ビター", "デュアルパーパス"];
  const filtered = selectedCategory === "all" ? hopVarieties : hopVarieties.filter((h) => h.category === selectedCategory);

  const categoryColors: Record<string, string> = {
    "ファインアロマ": "bg-emerald-100 text-emerald-800 border-emerald-200",
    "アロマ": "bg-amber-100 text-amber-800 border-amber-200",
    "ビター": "bg-red-100 text-red-800 border-red-200",
    "デュアルパーパス": "bg-blue-100 text-blue-800 border-blue-200",
  };

  return (
    <section id="hop-types" className="py-24 washi-texture">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <FadeInSection>
          <div className="text-center mb-16">
            <span className="inline-block text-[#69B076] text-sm tracking-[0.2em] font-medium mb-3">第一章</span>
            <h2 className="text-3xl sm:text-4xl font-bold text-[#2B2B2B] mb-4" style={{ fontFamily: "'Zen Maru Gothic', sans-serif" }}>
              ホップの種類と品種
            </h2>
            <p className="text-[#2B2B2B]/60 max-w-2xl mx-auto">
              世界には300種類以上のホップが存在します。用途や香りの特徴で大きく4つに分類されます。
            </p>
          </div>
        </FadeInSection>

        <FadeInSection delay={0.1}>
          <div className="relative mb-12">
            <img src={IMAGES.hopVarieties} alt="ホップの品種" className="w-full h-64 sm:h-80 object-cover rounded-2xl shadow-lg" />
            <div className="absolute inset-0 bg-gradient-to-t from-[#2B2B2B]/60 to-transparent rounded-2xl" />
            <div className="absolute bottom-6 left-6 right-6">
              <p className="text-white/90 text-sm sm:text-base">
                ホップの毬花（きゅうか）には「ルプリン」と呼ばれる黄色い粉が含まれ、ここにα酸（苦味）と精油（香り）が凝縮されています。
              </p>
            </div>
          </div>
        </FadeInSection>

        <FadeInSection delay={0.2}>
          <div className="flex flex-wrap gap-2 justify-center mb-10">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => { setSelectedCategory(cat); setSelectedHop(null); }}
                className={`px-5 py-2.5 rounded-full text-sm font-medium transition-all border ${
                  selectedCategory === cat
                    ? "bg-[#69B076] text-white border-[#69B076] shadow-md"
                    : "bg-white text-[#2B2B2B]/70 border-[#2B2B2B]/10 hover:border-[#69B076]/40"
                }`}
              >
                {cat === "all" ? "すべて" : cat}
              </button>
            ))}
          </div>
        </FadeInSection>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map((hop, i) => (
            <FadeInSection key={hop.nameEn} delay={i * 0.05}>
              <div
                onClick={() => setSelectedHop(selectedHop?.nameEn === hop.nameEn ? null : hop)}
                className={`bg-white rounded-xl p-5 border transition-all cursor-pointer hover:shadow-lg ${
                  selectedHop?.nameEn === hop.nameEn ? "border-[#69B076] shadow-lg ring-2 ring-[#69B076]/20" : "border-[#2B2B2B]/5 hover:border-[#69B076]/30"
                }`}
              >
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <h3 className="font-bold text-[#2B2B2B] text-lg" style={{ fontFamily: "'Zen Maru Gothic', sans-serif" }}>{hop.name}</h3>
                    <p className="text-[#2B2B2B]/40 text-xs" style={{ fontFamily: "'DM Sans', sans-serif" }}>{hop.nameEn}</p>
                  </div>
                  <span className={`text-xs px-2.5 py-1 rounded-full border ${categoryColors[hop.category]}`}>
                    {hop.category}
                  </span>
                </div>
                <div className="flex items-center gap-3 text-xs text-[#2B2B2B]/50 mb-3">
                  <span>🌍 {hop.origin}</span>
                  <span>α酸 {hop.alphaAcid}</span>
                </div>
                <p className="text-sm text-[#2B2B2B]/60 mb-3">🌿 {hop.aroma}</p>
                <div className="flex flex-wrap gap-1.5">
                  {hop.grownInJapan && (
                    <span className="text-xs px-2 py-0.5 rounded-full bg-[#69B076]/10 text-[#69B076] border border-[#69B076]/20">🇯🇵 日本栽培</span>
                  )}
                  {hop.chibaFriendly && (
                    <span className="text-xs px-2 py-0.5 rounded-full bg-[#C75B3B]/10 text-[#C75B3B] border border-[#C75B3B]/20">千葉向き</span>
                  )}
                </div>

                {selectedHop?.nameEn === hop.nameEn && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: "auto" }}
                    className="mt-4 pt-4 border-t border-[#2B2B2B]/5"
                  >
                    <p className="text-sm text-[#2B2B2B]/70 mb-3 leading-relaxed">{hop.description}</p>
                    <div>
                      <p className="text-xs font-medium text-[#2B2B2B]/50 mb-1.5">おすすめビールスタイル：</p>
                      <div className="flex flex-wrap gap-1.5">
                        {hop.beerStyles.map((style) => (
                          <span key={style} className="text-xs px-2 py-0.5 rounded-full bg-[#C68B3F]/10 text-[#C68B3F] border border-[#C68B3F]/20">
                            {style}
                          </span>
                        ))}
                      </div>
                    </div>
                  </motion.div>
                )}
              </div>
            </FadeInSection>
          ))}
        </div>
      </div>
    </section>
  );
}

// ===== Beer Styles Section =====
function BeerStylesSection() {
  const [selectedStyle, setSelectedStyle] = useState<BeerStyle | null>(null);

  return (
    <section id="beer-styles" className="py-24 bg-[#2B2B2B]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <FadeInSection>
          <div className="text-center mb-16">
            <span className="inline-block text-[#C68B3F] text-sm tracking-[0.2em] font-medium mb-3">第二章</span>
            <h2 className="text-3xl sm:text-4xl font-bold text-white mb-4" style={{ fontFamily: "'Zen Maru Gothic', sans-serif" }}>
              ビールの種類と発酵
            </h2>
            <p className="text-white/50 max-w-2xl mx-auto">
              発酵方法の違いがビールの個性を決定づけます。エール、ラガー、自然発酵の3つの世界を探索しましょう。
            </p>
          </div>
        </FadeInSection>

        <FadeInSection delay={0.1}>
          <div className="relative mb-14">
            <img src={IMAGES.beerVarieties} alt="ビールの種類" className="w-full h-64 sm:h-80 object-cover rounded-2xl" />
            <div className="absolute inset-0 bg-gradient-to-t from-[#2B2B2B] via-transparent to-transparent rounded-2xl" />
          </div>
        </FadeInSection>

        <FadeInSection delay={0.15}>
          <Tabs defaultValue="ale" className="w-full">
            <TabsList className="w-full max-w-lg mx-auto grid grid-cols-3 bg-white/5 rounded-xl p-1 mb-10">
              <TabsTrigger value="ale" className="rounded-lg text-white/70 data-[state=active]:bg-[#C68B3F] data-[state=active]:text-white">
                上面発酵（エール）
              </TabsTrigger>
              <TabsTrigger value="lager" className="rounded-lg text-white/70 data-[state=active]:bg-[#C68B3F] data-[state=active]:text-white">
                下面発酵（ラガー）
              </TabsTrigger>
              <TabsTrigger value="wild" className="rounded-lg text-white/70 data-[state=active]:bg-[#C68B3F] data-[state=active]:text-white">
                自然発酵
              </TabsTrigger>
            </TabsList>

            {(["ale", "lager", "wild"] as const).map((type) => {
              const fermentationMap = {
                ale: "上面発酵（エール）",
                lager: "下面発酵（ラガー）",
                wild: "自然発酵",
              } as const;
              const styles = beerStyles.filter((s) => s.fermentation === fermentationMap[type]);
              return (
                <TabsContent key={type} value={type}>
                  <div className="mb-8 bg-white/5 rounded-xl p-6">
                    <h3 className="text-white font-bold text-lg mb-2" style={{ fontFamily: "'Zen Maru Gothic', sans-serif" }}>
                      {type === "ale" && "上面発酵（エール）— 18〜22℃"}
                      {type === "lager" && "下面発酵（ラガー）— 9〜13℃"}
                      {type === "wild" && "自然発酵 — 自然環境温度"}
                    </h3>
                    <p className="text-white/50 text-sm">
                      {type === "ale" && "上面発酵酵母（Saccharomyces cerevisiae）を使用。高温で活発に発酵し、フルーティなエステルやスパイシーなフェノールを生成。豊かな風味が特徴。"}
                      {type === "lager" && "下面発酵酵母（Saccharomyces pastorianus）を使用。低温でゆっくり発酵し、クリーンでスムーズな味わいを生む。長期熟成（ラガリング）が必要。"}
                      {type === "wild" && "空気中の野生酵母やバクテリアで自然に発酵。予測不能な複雑さと酸味が魅力。ベルギーのランビック地方が本場。"}
                    </p>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                    {styles.map((style) => (
                      <div
                        key={style.nameEn}
                        onClick={() => setSelectedStyle(selectedStyle?.nameEn === style.nameEn ? null : style)}
                        className={`rounded-xl p-5 border transition-all cursor-pointer ${
                          selectedStyle?.nameEn === style.nameEn
                            ? "bg-white/15 border-[#C68B3F] ring-1 ring-[#C68B3F]/30"
                            : "bg-white/5 border-white/5 hover:bg-white/10 hover:border-white/10"
                        }`}
                      >
                        <div className="flex items-center gap-3 mb-3">
                          <div className="w-8 h-8 rounded-full shadow-inner border border-white/10" style={{ backgroundColor: style.colorHex }} />
                          <div>
                            <h4 className="text-white font-bold" style={{ fontFamily: "'Zen Maru Gothic', sans-serif" }}>{style.name}</h4>
                            <p className="text-white/30 text-xs" style={{ fontFamily: "'DM Sans', sans-serif" }}>{style.nameEn}</p>
                          </div>
                        </div>
                        <div className="grid grid-cols-3 gap-2 text-xs text-white/40 mb-3">
                          <div>
                            <span className="block text-white/20">IBU</span>
                            {style.ibu}
                          </div>
                          <div>
                            <span className="block text-white/20">ABV</span>
                            {style.abv}
                          </div>
                          <div>
                            <span className="block text-white/20">発酵温度</span>
                            {style.fermentationTemp}
                          </div>
                        </div>
                        <p className="text-white/40 text-xs">{style.color} | {style.origin}</p>

                        {selectedStyle?.nameEn === style.nameEn && (
                          <motion.div
                            initial={{ opacity: 0, height: 0 }}
                            animate={{ opacity: 1, height: "auto" }}
                            className="mt-4 pt-4 border-t border-white/10"
                          >
                            <p className="text-white/60 text-sm mb-3 leading-relaxed">{style.description}</p>
                            <div>
                              <p className="text-xs text-white/30 mb-1.5">おすすめホップ：</p>
                              <div className="flex flex-wrap gap-1.5">
                                {style.recommendedHops.map((hop) => (
                                  <span key={hop} className="text-xs px-2 py-0.5 rounded-full bg-[#69B076]/20 text-[#69B076] border border-[#69B076]/20">
                                    {hop}
                                  </span>
                                ))}
                              </div>
                            </div>
                          </motion.div>
                        )}
                      </div>
                    ))}
                  </div>
                </TabsContent>
              );
            })}
          </Tabs>
        </FadeInSection>
      </div>
    </section>
  );
}

// ===== Brewing Process Section =====
function BrewingSection() {
  const [activeStep, setActiveStep] = useState(0);

  return (
    <section id="brewing" className="py-24 washi-texture">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <FadeInSection>
          <div className="text-center mb-16">
            <span className="inline-block text-[#C68B3F] text-sm tracking-[0.2em] font-medium mb-3">第三章</span>
            <h2 className="text-3xl sm:text-4xl font-bold text-[#2B2B2B] mb-4" style={{ fontFamily: "'Zen Maru Gothic', sans-serif" }}>
              ビール醸造の一から十
            </h2>
            <p className="text-[#2B2B2B]/60 max-w-2xl mx-auto">
              原料選定から完成まで、全10工程を詳しく解説。自家醸造への道を一歩ずつ進みましょう。
            </p>
          </div>
        </FadeInSection>

        <FadeInSection delay={0.1}>
          <div className="relative mb-14">
            <img src={IMAGES.brewingProcess} alt="醸造プロセス" className="w-full h-64 sm:h-80 object-cover rounded-2xl shadow-lg" />
            <div className="absolute inset-0 bg-gradient-to-t from-[#FAF6F0] via-transparent to-transparent rounded-2xl" />
          </div>
        </FadeInSection>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Step list */}
          <div className="lg:col-span-4">
            <div className="sticky top-24 space-y-1">
              {brewingSteps.map((step, i) => (
                <button
                  key={step.step}
                  onClick={() => setActiveStep(i)}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-left transition-all ${
                    activeStep === i
                      ? "bg-[#69B076] text-white shadow-md"
                      : "text-[#2B2B2B]/60 hover:bg-[#69B076]/5 hover:text-[#2B2B2B]"
                  }`}
                >
                  <span className="text-2xl">{step.icon}</span>
                  <div>
                    <span className={`text-xs ${activeStep === i ? "text-white/70" : "text-[#2B2B2B]/30"}`} style={{ fontFamily: "'DM Sans', sans-serif" }}>
                      Step {step.step}
                    </span>
                    <p className="font-medium text-sm" style={{ fontFamily: "'Zen Maru Gothic', sans-serif" }}>{step.title}</p>
                  </div>
                  {activeStep === i && <ChevronRight className="w-4 h-4 ml-auto" />}
                </button>
              ))}
            </div>
          </div>

          {/* Step detail */}
          <div className="lg:col-span-8">
            <motion.div
              key={activeStep}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.4 }}
              className="bg-white rounded-2xl p-8 shadow-sm border border-[#2B2B2B]/5"
            >
              <div className="flex items-center gap-4 mb-6">
                <span className="text-5xl">{brewingSteps[activeStep].icon}</span>
                <div>
                  <p className="text-[#69B076] text-sm font-medium" style={{ fontFamily: "'DM Sans', sans-serif" }}>
                    Step {brewingSteps[activeStep].step} — {brewingSteps[activeStep].titleEn}
                  </p>
                  <h3 className="text-2xl font-bold text-[#2B2B2B]" style={{ fontFamily: "'Zen Maru Gothic', sans-serif" }}>
                    {brewingSteps[activeStep].title}
                  </h3>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4 mb-6">
                <div className="bg-[#69B076]/5 rounded-xl p-4">
                  <p className="text-xs text-[#69B076] font-medium mb-1">所要時間</p>
                  <p className="text-[#2B2B2B] font-bold">{brewingSteps[activeStep].duration}</p>
                </div>
                <div className="bg-[#C68B3F]/5 rounded-xl p-4">
                  <p className="text-xs text-[#C68B3F] font-medium mb-1">温度</p>
                  <p className="text-[#2B2B2B] font-bold">{brewingSteps[activeStep].temperature}</p>
                </div>
              </div>

              <p className="text-[#2B2B2B]/70 leading-relaxed mb-6">
                {brewingSteps[activeStep].description}
              </p>

              <div className="bg-[#C68B3F]/5 border border-[#C68B3F]/10 rounded-xl p-4">
                <p className="text-sm font-medium text-[#C68B3F] mb-1">💡 ワンポイントアドバイス</p>
                <p className="text-sm text-[#2B2B2B]/60">{brewingSteps[activeStep].tips}</p>
              </div>

              <div className="flex justify-between mt-8">
                <button
                  onClick={() => setActiveStep(Math.max(0, activeStep - 1))}
                  disabled={activeStep === 0}
                  className="px-4 py-2 rounded-lg text-sm font-medium text-[#2B2B2B]/50 hover:text-[#2B2B2B] hover:bg-[#2B2B2B]/5 disabled:opacity-30 disabled:cursor-not-allowed transition-all"
                >
                  ← 前の工程
                </button>
                <button
                  onClick={() => setActiveStep(Math.min(brewingSteps.length - 1, activeStep + 1))}
                  disabled={activeStep === brewingSteps.length - 1}
                  className="px-4 py-2 rounded-lg text-sm font-medium bg-[#69B076] text-white hover:bg-[#5A9A66] disabled:opacity-30 disabled:cursor-not-allowed transition-all"
                >
                  次の工程 →
                </button>
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  );
}

// ===== Chiba Growing Section =====
function ChibaSection() {
  const calendarData = [
    { month: "2月", task: "土壌準備・施肥", detail: "苦土石灰でpH調整、有機肥料を施す", color: "bg-amber-100 text-amber-800" },
    { month: "3〜4月", task: "苗植え付け", detail: "株分けした根を30cm間隔で植える", color: "bg-green-100 text-green-800" },
    { month: "4月", task: "糸下げ・萌芽管理", detail: "支柱とネットを設置、蔓を誘引", color: "bg-green-100 text-green-800" },
    { month: "5月", task: "選芽・蔓上げ・追肥", detail: "5〜8本に選芽、蔓を上方へ誘引", color: "bg-emerald-100 text-emerald-800" },
    { month: "6月", task: "遮光ネット設置", detail: "遮光率50〜70%のネットで暑さ対策", color: "bg-yellow-100 text-yellow-800" },
    { month: "6月下旬〜7月", task: "収穫", detail: "毬花が黄緑色になり香りが立ったら収穫", color: "bg-red-100 text-red-800" },
    { month: "収穫後", task: "乾燥・保存", detail: "すぐに乾燥、またはウェットホップとして24h以内に使用", color: "bg-purple-100 text-purple-800" },
    { month: "冬", task: "越冬管理", detail: "地上部は枯死、根は越冬。マルチングで保護", color: "bg-blue-100 text-blue-800" },
  ];

  return (
    <section id="chiba" className="py-24 bg-[#F0EDE5]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <FadeInSection>
          <div className="text-center mb-16">
            <span className="inline-block text-[#C75B3B] text-sm tracking-[0.2em] font-medium mb-3">第四章</span>
            <h2 className="text-3xl sm:text-4xl font-bold text-[#2B2B2B] mb-4" style={{ fontFamily: "'Zen Maru Gothic', sans-serif" }}>
              千葉県北部でホップを育てる
            </h2>
            <p className="text-[#2B2B2B]/60 max-w-2xl mx-auto">
              温暖な千葉県北部でのホップ栽培は挑戦的ですが、適切な品種選定と暑さ対策で成功できます。
            </p>
          </div>
        </FadeInSection>

        <FadeInSection delay={0.1}>
          <div className="relative mb-14">
            <img src={IMAGES.chibaLandscape} alt="千葉県北部の風景" className="w-full h-64 sm:h-80 object-cover rounded-2xl shadow-lg" />
            <div className="absolute inset-0 bg-gradient-to-r from-[#2B2B2B]/60 to-transparent rounded-2xl" />
            <div className="absolute bottom-6 left-6 right-6 sm:right-auto sm:max-w-md">
              <h3 className="text-white font-bold text-xl mb-2" style={{ fontFamily: "'Zen Maru Gothic', sans-serif" }}>千葉県北部の気候</h3>
              <div className="grid grid-cols-2 gap-3">
                <div className="bg-white/15 backdrop-blur-sm rounded-lg p-3">
                  <Thermometer className="w-4 h-4 text-white/70 mb-1" />
                  <p className="text-white text-sm font-bold">年平均 14.0〜14.3℃</p>
                </div>
                <div className="bg-white/15 backdrop-blur-sm rounded-lg p-3">
                  <Droplets className="w-4 h-4 text-white/70 mb-1" />
                  <p className="text-white text-sm font-bold">年降水量 1,322〜1,355mm</p>
                </div>
              </div>
            </div>
          </div>
        </FadeInSection>

        {/* Growing conditions */}
        <FadeInSection delay={0.2}>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-14">
            <div className="bg-white rounded-2xl p-6 shadow-sm border border-[#2B2B2B]/5">
              <h3 className="font-bold text-lg text-[#2B2B2B] mb-4 flex items-center gap-2" style={{ fontFamily: "'Zen Maru Gothic', sans-serif" }}>
                <Sun className="w-5 h-5 text-[#C75B3B]" /> 栽培の課題と対策
              </h3>
              <div className="space-y-3">
                {[
                  { issue: "夏の高温多湿", solution: "遮光ネット（50〜70%）、マルチング、朝夕の灌水" },
                  { issue: "土壌の酸性傾向", solution: "苦土石灰でpH 6〜7に調整" },
                  { issue: "台風・強風", solution: "しっかりした支柱とネット、風よけの設置" },
                  { issue: "病害虫", solution: "風通しの良い環境、適度な間引き" },
                ].map((item) => (
                  <div key={item.issue} className="flex gap-3">
                    <span className="text-[#C75B3B] text-sm mt-0.5">▸</span>
                    <div>
                      <p className="text-sm font-medium text-[#2B2B2B]">{item.issue}</p>
                      <p className="text-xs text-[#2B2B2B]/50">{item.solution}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-white rounded-2xl p-6 shadow-sm border border-[#2B2B2B]/5">
              <h3 className="font-bold text-lg text-[#2B2B2B] mb-4 flex items-center gap-2" style={{ fontFamily: "'Zen Maru Gothic', sans-serif" }}>
                <Leaf className="w-5 h-5 text-[#69B076]" /> 千葉向きの品種
              </h3>
              <div className="space-y-4">
                {hopVarieties.filter((h) => h.chibaFriendly).map((hop) => (
                  <div key={hop.nameEn} className="bg-[#69B076]/5 rounded-xl p-4 border border-[#69B076]/10">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-bold text-[#2B2B2B]" style={{ fontFamily: "'Zen Maru Gothic', sans-serif" }}>{hop.name}（{hop.nameEn}）</h4>
                      <span className="text-xs text-[#69B076]">α酸 {hop.alphaAcid}</span>
                    </div>
                    <p className="text-sm text-[#2B2B2B]/60">{hop.description}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </FadeInSection>

        {/* Calendar */}
        <FadeInSection delay={0.3}>
          <div className="bg-white rounded-2xl p-6 sm:p-8 shadow-sm border border-[#2B2B2B]/5">
            <h3 className="font-bold text-xl text-[#2B2B2B] mb-6 flex items-center gap-2" style={{ fontFamily: "'Zen Maru Gothic', sans-serif" }}>
              <Calendar className="w-5 h-5 text-[#C68B3F]" /> 栽培カレンダー（千葉県北部向け）
            </h3>
            <div className="space-y-3">
              {calendarData.map((item) => (
                <div key={item.month} className="flex items-start gap-4 group">
                  <div className="w-24 shrink-0">
                    <span className={`inline-block text-xs font-medium px-3 py-1.5 rounded-full ${item.color}`}>
                      {item.month}
                    </span>
                  </div>
                  <div className="flex-1 pb-3 border-b border-[#2B2B2B]/5">
                    <p className="font-medium text-sm text-[#2B2B2B]">{item.task}</p>
                    <p className="text-xs text-[#2B2B2B]/50">{item.detail}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </FadeInSection>

        {/* Chiba breweries */}
        <FadeInSection delay={0.4}>
          <div className="mt-14 bg-[#69B076]/10 rounded-2xl p-6 sm:p-8 border border-[#69B076]/20">
            <h3 className="font-bold text-xl text-[#2B2B2B] mb-4" style={{ fontFamily: "'Zen Maru Gothic', sans-serif" }}>
              🍺 千葉県のホップ栽培事例
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              {[
                { place: "JR松戸駅 屋上農園", detail: "2025年、駅舎屋上でホップ栽培に挑戦。オリジナルクラフトビールの醸造を目指す。" },
                { place: "こまいぬブルワリー（柏市）", detail: "自社農園でホップを栽培し、地元産ビールを醸造。家族連れにも人気。" },
                { place: "東大むら塾（富津市）", detail: "東京大学の学生が富津市でホップ栽培。鋸南町の醸造所とコラボでビール製造。" },
              ].map((item) => (
                <div key={item.place} className="bg-white rounded-xl p-4">
                  <h4 className="font-bold text-sm text-[#2B2B2B] mb-2" style={{ fontFamily: "'Zen Maru Gothic', sans-serif" }}>{item.place}</h4>
                  <p className="text-xs text-[#2B2B2B]/60">{item.detail}</p>
                </div>
              ))}
            </div>
          </div>
        </FadeInSection>
      </div>
    </section>
  );
}

// ===== Hop-Beer Relationship Chart =====
function HopBeerRelationship() {
  const relationships = [
    { hop: "カスケード", beer: "ペールエール", fermentation: "上面発酵", aroma: "グレープフルーツ", bitterness: "中", color: "#D4A03C" },
    { hop: "シトラ", beer: "ヘイジーIPA", fermentation: "上面発酵", aroma: "トロピカル", bitterness: "中〜高", color: "#E8C547" },
    { hop: "モザイク", beer: "IPA", fermentation: "上面発酵", aroma: "ベリー・マンゴー", bitterness: "高", color: "#C68B3F" },
    { hop: "ザーツ", beer: "ピルスナー", fermentation: "下面発酵", aroma: "スパイシー", bitterness: "低〜中", color: "#F5D76E" },
    { hop: "テトナング", beer: "ヴァイツェン", fermentation: "上面発酵", aroma: "フローラル", bitterness: "低", color: "#F0C75E" },
    { hop: "ソラチエース", beer: "セゾン", fermentation: "上面発酵", aroma: "レモングラス", bitterness: "中", color: "#F5D76E" },
    { hop: "チヌーク", beer: "スタウト", fermentation: "上面発酵", aroma: "松・グレープフルーツ", bitterness: "高", color: "#1A1A1A" },
    { hop: "ケントゴールディングス", beer: "ESB", fermentation: "上面発酵", aroma: "ハニー", bitterness: "中", color: "#B5651D" },
    { hop: "マグナム", beer: "ピルスナー", fermentation: "下面発酵", aroma: "クリーン", bitterness: "高", color: "#F5D76E" },
    { hop: "ゼウス", beer: "IPA", fermentation: "上面発酵", aroma: "スパイシー", bitterness: "高", color: "#C68B3F" },
    { hop: "センテニアル", beer: "ペールエール", fermentation: "上面発酵", aroma: "シトラス", bitterness: "中〜高", color: "#D4A03C" },
    { hop: "ネルソンソーヴィン", beer: "IPA", fermentation: "上面発酵", aroma: "白ワイン", bitterness: "高", color: "#C68B3F" },
  ];

  return (
    <section className="py-24 bg-[#2B2B2B]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <FadeInSection>
          <div className="text-center mb-16">
            <span className="inline-block text-[#C68B3F] text-sm tracking-[0.2em] font-medium mb-3">第五章</span>
            <h2 className="text-3xl sm:text-4xl font-bold text-white mb-4" style={{ fontFamily: "'Zen Maru Gothic', sans-serif" }}>
              ホップ × ビール × 発酵の関係
            </h2>
            <p className="text-white/50 max-w-2xl mx-auto">
              どのホップがどのビールスタイルに合い、どの発酵方法で醸造されるのか。一覧で確認しましょう。
            </p>
          </div>
        </FadeInSection>

        <FadeInSection delay={0.1}>
          <div className="overflow-x-auto rounded-2xl">
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-white/10">
                  <th className="text-left text-white/70 font-medium px-4 py-3">ホップ品種</th>
                  <th className="text-left text-white/70 font-medium px-4 py-3">ビールスタイル</th>
                  <th className="text-left text-white/70 font-medium px-4 py-3">発酵方法</th>
                  <th className="text-left text-white/70 font-medium px-4 py-3">主な香り</th>
                  <th className="text-left text-white/70 font-medium px-4 py-3">苦味</th>
                  <th className="text-left text-white/70 font-medium px-4 py-3">色</th>
                </tr>
              </thead>
              <tbody>
                {relationships.map((r, i) => (
                  <tr key={i} className="border-t border-white/5 hover:bg-white/5 transition-colors">
                    <td className="px-4 py-3 text-white font-medium">{r.hop}</td>
                    <td className="px-4 py-3 text-white/70">{r.beer}</td>
                    <td className="px-4 py-3">
                      <span className={`text-xs px-2 py-0.5 rounded-full ${
                        r.fermentation === "上面発酵" ? "bg-[#C68B3F]/20 text-[#C68B3F]" : "bg-[#69B076]/20 text-[#69B076]"
                      }`}>
                        {r.fermentation}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-white/50">{r.aroma}</td>
                    <td className="px-4 py-3 text-white/50">{r.bitterness}</td>
                    <td className="px-4 py-3">
                      <div className="w-6 h-6 rounded-full border border-white/10" style={{ backgroundColor: r.color }} />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </FadeInSection>
      </div>
    </section>
  );
}

// ===== Quiz Section (200問×10レベル) =====
const QUESTIONS_PER_LEVEL = 20;
const TOTAL_LEVELS = 10;
const PASS_THRESHOLD = 0.8; // 80%

const levelIcons = [Leaf, Star, Zap, Target, Flame, Beer, FlaskConical, Crown, Trophy, Trophy];
const levelColors = [
  "from-green-400 to-green-600",
  "from-emerald-400 to-emerald-600",
  "from-teal-400 to-teal-600",
  "from-cyan-400 to-cyan-600",
  "from-blue-400 to-blue-600",
  "from-indigo-400 to-indigo-600",
  "from-violet-400 to-violet-600",
  "from-purple-400 to-purple-600",
  "from-amber-400 to-amber-600",
  "from-red-400 to-red-600",
];

function shuffleArray<T>(arr: T[]): T[] {
  const shuffled = [...arr];
  for (let i = shuffled.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
  }
  return shuffled;
}

function getLevelQuestions(level: number, shouldShuffle: boolean): QuizQuestion[] {
  // Each level picks 20 questions: 4 from each of the 5 themes, progressing in difficulty
  const startIdx = (level - 1) * 4; // each theme has 40 Qs, pick 4 per level
  const questions: QuizQuestion[] = [];
  for (const theme of QUIZ_THEMES) {
    const themeQs = allQuizQuestions.filter((q) => q.theme === theme);
    const slice = themeQs.slice(startIdx, startIdx + 4);
    questions.push(...slice);
  }
  return shouldShuffle ? shuffleArray(questions) : questions;
}

function QuizSection() {
  const [highestUnlocked, setHighestUnlocked] = useState(1);
  const [currentLevel, setCurrentLevel] = useState(0); // 0 = not started
  const [currentQ, setCurrentQ] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [score, setScore] = useState(0);
  const [showResult, setShowResult] = useState(false);
  const [shouldShuffle, setShouldShuffle] = useState(false);
  const [levelQuestions, setLevelQuestions] = useState<QuizQuestion[]>([]);
  const [levelScores, setLevelScores] = useState<Record<number, number>>({});

  const question = levelQuestions[currentQ];

  const startLevel = (level: number) => {
    const qs = getLevelQuestions(level, shouldShuffle);
    setLevelQuestions(qs);
    setCurrentLevel(level);
    setCurrentQ(0);
    setSelectedAnswer(null);
    setScore(0);
    setShowResult(false);
  };

  const handleAnswer = (index: number) => {
    if (selectedAnswer !== null) return;
    setSelectedAnswer(index);
    if (index === question.correctIndex) setScore((s) => s + 1);
  };

  const nextQuestion = () => {
    if (currentQ < levelQuestions.length - 1) {
      setCurrentQ((q) => q + 1);
      setSelectedAnswer(null);
    } else {
      setShowResult(true);
      const finalScore = score + (selectedAnswer === question.correctIndex ? 0 : 0);
      // score is already updated via handleAnswer
      setLevelScores((prev) => ({ ...prev, [currentLevel]: score }));
      if (score / QUESTIONS_PER_LEVEL >= PASS_THRESHOLD && currentLevel >= highestUnlocked) {
        setHighestUnlocked(Math.min(currentLevel + 1, TOTAL_LEVELS));
      }
    }
  };

  const passRate = score / QUESTIONS_PER_LEVEL;
  const passed = passRate >= PASS_THRESHOLD;

  return (
    <section id="quiz" className="py-24 washi-texture">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <FadeInSection>
          <div className="text-center mb-12">
            <span className="inline-block text-[#C75B3B] text-sm tracking-[0.2em] font-medium mb-3">第六章</span>
            <h2 className="text-3xl sm:text-4xl font-bold text-[#2B2B2B] mb-4" style={{ fontFamily: "'Zen Maru Gothic', sans-serif" }}>
              知識チェッククイズ
            </h2>
            <p className="text-[#2B2B2B]/60 max-w-2xl mx-auto">
              200問・全10レベルの段階式クイズ。各レベル20問中80%以上正解で次のレベルが解放されます。
            </p>
          </div>
        </FadeInSection>

        {/* Overall Progress Bar */}
        <FadeInSection delay={0.05}>
          <div className="bg-white rounded-2xl p-5 mb-8 shadow-sm border border-[#2B2B2B]/5">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-bold text-[#2B2B2B]" style={{ fontFamily: "'Zen Maru Gothic', sans-serif" }}>
                全体の進捗
              </h3>
              <span className="text-xs text-[#2B2B2B]/40" style={{ fontFamily: "'DM Sans', sans-serif" }}>
                {highestUnlocked - 1} / {TOTAL_LEVELS} レベルクリア
              </span>
            </div>
            <div className="flex gap-1 mb-3">
              {Array.from({ length: TOTAL_LEVELS }, (_, i) => i + 1).map((level) => {
                const Icon = levelIcons[level - 1];
                const isUnlocked = level <= highestUnlocked;
                const isCompleted = levelScores[level] !== undefined && levelScores[level] / QUESTIONS_PER_LEVEL >= PASS_THRESHOLD;
                return (
                  <div key={level} className="flex-1 flex flex-col items-center gap-1">
                    <div
                      className={`w-full h-3 rounded-full transition-all duration-500 ${
                        isCompleted
                          ? `bg-gradient-to-r ${levelColors[level - 1]}`
                          : level === highestUnlocked
                          ? "bg-gradient-to-r from-[#69B076]/30 to-[#69B076]/50 animate-pulse"
                          : "bg-[#2B2B2B]/5"
                      }`}
                    />
                    <span className={`text-[10px] font-medium ${
                      isCompleted ? "text-[#69B076]" : isUnlocked ? "text-[#2B2B2B]/50" : "text-[#2B2B2B]/20"
                    }`} style={{ fontFamily: "'DM Sans', sans-serif" }}>
                      {level}
                    </span>
                  </div>
                );
              })}
            </div>
            {/* Shuffle toggle */}
            <div className="flex items-center justify-between pt-3 border-t border-[#2B2B2B]/5">
              <div className="flex items-center gap-2 text-sm text-[#2B2B2B]/60">
                <Shuffle className="w-4 h-4" />
                <span>問題シャッフル</span>
              </div>
              <button
                onClick={() => setShouldShuffle(!shouldShuffle)}
                className={`relative w-12 h-6 rounded-full transition-all ${
                  shouldShuffle ? "bg-[#69B076]" : "bg-[#2B2B2B]/10"
                }`}
              >
                <div className={`absolute top-0.5 w-5 h-5 rounded-full bg-white shadow transition-all ${
                  shouldShuffle ? "left-6" : "left-0.5"
                }`} />
              </button>
            </div>
          </div>
        </FadeInSection>

        {currentLevel === 0 ? (
          /* Level Selection Grid */
          <FadeInSection delay={0.1}>
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
              {Array.from({ length: TOTAL_LEVELS }, (_, i) => i + 1).map((level) => {
                const Icon = levelIcons[level - 1];
                const isUnlocked = level <= highestUnlocked;
                const scoreVal = levelScores[level];
                const isCompleted = scoreVal !== undefined && scoreVal / QUESTIONS_PER_LEVEL >= PASS_THRESHOLD;
                return (
                  <button
                    key={level}
                    onClick={() => isUnlocked && startLevel(level)}
                    disabled={!isUnlocked}
                    className={`relative rounded-2xl p-4 sm:p-5 border transition-all text-center group ${
                      isUnlocked
                        ? isCompleted
                          ? "bg-white border-[#69B076]/30 hover:shadow-lg hover:border-[#69B076]"
                          : "bg-white border-[#2B2B2B]/5 hover:shadow-lg hover:border-[#C68B3F]/40"
                        : "bg-[#2B2B2B]/[0.02] border-[#2B2B2B]/5 cursor-not-allowed opacity-50"
                    }`}
                  >
                    {isCompleted && (
                      <div className="absolute -top-2 -right-2 w-6 h-6 rounded-full bg-[#69B076] flex items-center justify-center">
                        <Check className="w-3.5 h-3.5 text-white" />
                      </div>
                    )}
                    <div className={`w-10 h-10 sm:w-12 sm:h-12 mx-auto rounded-xl flex items-center justify-center mb-2 ${
                      isUnlocked
                        ? `bg-gradient-to-br ${levelColors[level - 1]} text-white`
                        : "bg-[#2B2B2B]/5 text-[#2B2B2B]/20"
                    }`}>
                      {isUnlocked ? <Icon className="w-5 h-5 sm:w-6 sm:h-6" /> : <Lock className="w-5 h-5" />}
                    </div>
                    <p className="text-xs font-bold text-[#2B2B2B] mb-0.5" style={{ fontFamily: "'DM Sans', sans-serif" }}>
                      Lv.{level}
                    </p>
                    <p className="text-[10px] text-[#2B2B2B]/40">
                      {isUnlocked ? (scoreVal !== undefined ? `${scoreVal}/${QUESTIONS_PER_LEVEL}` : "未挑戦") : "🔒"}
                    </p>
                  </button>
                );
              })}
            </div>
          </FadeInSection>
        ) : showResult ? (
          /* Result Screen */
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-white rounded-2xl p-8 text-center shadow-sm border border-[#2B2B2B]/5"
          >
            <div className={`w-20 h-20 mx-auto rounded-full flex items-center justify-center mb-4 bg-gradient-to-br ${
              passed ? "from-green-400 to-emerald-600" : "from-amber-400 to-orange-500"
            }`}>
              {passed ? <Trophy className="w-10 h-10 text-white" /> : <RotateCcw className="w-10 h-10 text-white" />}
            </div>
            <h3 className="text-2xl font-bold text-[#2B2B2B] mb-2" style={{ fontFamily: "'Zen Maru Gothic', sans-serif" }}>
              {passed ? (score === QUESTIONS_PER_LEVEL ? "パーフェクト！" : "合格！") : "もう少し！"}
            </h3>
            <p className="text-5xl font-bold mb-1" style={{ fontFamily: "'DM Sans', sans-serif", color: passed ? "#69B076" : "#C68B3F" }}>
              {score}/{QUESTIONS_PER_LEVEL}
            </p>
            <p className="text-sm text-[#2B2B2B]/40 mb-2">
              正解率 {Math.round(passRate * 100)}%
              {passed ? " — 80%以上で合格！" : " — 80%以上で次のレベルへ"}
            </p>
            <p className="text-sm text-[#2B2B2B]/50 mb-8" style={{ fontFamily: "'Zen Maru Gothic', sans-serif" }}>
              レベル {currentLevel} / {TOTAL_LEVELS}
            </p>

            <div className="flex flex-col sm:flex-row gap-3 justify-center">
              <button
                onClick={() => startLevel(currentLevel)}
                className="px-6 py-3 rounded-full bg-[#2B2B2B]/5 text-[#2B2B2B]/70 font-medium hover:bg-[#2B2B2B]/10 transition-all flex items-center justify-center gap-2"
              >
                <RotateCcw className="w-4 h-4" /> もう一度挑戦
              </button>
              {passed && currentLevel < TOTAL_LEVELS && (
                <button
                  onClick={() => startLevel(currentLevel + 1)}
                  className="px-6 py-3 rounded-full bg-gradient-to-r from-[#69B076] to-[#5A9A66] text-white font-medium hover:shadow-lg transition-all flex items-center justify-center gap-2"
                >
                  レベル {currentLevel + 1} へ進む <ChevronRight className="w-4 h-4" />
                </button>
              )}
              <button
                onClick={() => { setCurrentLevel(0); setShowResult(false); }}
                className="px-6 py-3 rounded-full border border-[#2B2B2B]/10 text-[#2B2B2B]/60 font-medium hover:bg-[#2B2B2B]/5 transition-all"
              >
                レベル選択に戻る
              </button>
            </div>
          </motion.div>
        ) : question ? (
          /* Quiz In Progress */
          <div>
            {/* Level + Question Progress */}
            <div className="flex items-center gap-3 mb-4">
              <span className={`text-xs px-3 py-1 rounded-full text-white bg-gradient-to-r ${levelColors[currentLevel - 1]} font-medium`}
                style={{ fontFamily: "'DM Sans', sans-serif" }}>
                Lv.{currentLevel}
              </span>
              <div className="flex-1 h-2.5 bg-[#2B2B2B]/5 rounded-full overflow-hidden">
                <motion.div
                  className={`h-full rounded-full bg-gradient-to-r ${levelColors[currentLevel - 1]}`}
                  initial={{ width: 0 }}
                  animate={{ width: `${((currentQ + 1) / QUESTIONS_PER_LEVEL) * 100}%` }}
                  transition={{ duration: 0.5, ease: "easeOut" }}
                />
              </div>
              <span className="text-sm text-[#2B2B2B]/40 font-medium" style={{ fontFamily: "'DM Sans', sans-serif" }}>
                {currentQ + 1}/{QUESTIONS_PER_LEVEL}
              </span>
            </div>

            {/* Theme badge */}
            <div className="flex items-center gap-2 mb-4">
              <span className="text-xs px-2.5 py-1 rounded-full bg-[#C68B3F]/10 text-[#C68B3F] border border-[#C68B3F]/20">
                {question.theme}
              </span>
              <span className="text-xs text-[#2B2B2B]/30">正解: {score}/{currentQ + (selectedAnswer !== null ? 1 : 0)}</span>
            </div>

            <motion.div
              key={`${currentLevel}-${currentQ}`}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.3 }}
              className="bg-white rounded-2xl p-6 sm:p-8 shadow-sm border border-[#2B2B2B]/5"
            >
              <h3 className="text-lg font-bold text-[#2B2B2B] mb-6 leading-relaxed" style={{ fontFamily: "'Zen Maru Gothic', sans-serif" }}>
                Q{currentQ + 1}. {question.question}
              </h3>

              <div className="space-y-3 mb-6">
                {question.options.map((opt: string, i: number) => {
                  const isSelected = selectedAnswer === i;
                  const isCorrect = i === question.correctIndex;
                  const showFeedback = selectedAnswer !== null;
                  return (
                    <button
                      key={i}
                      onClick={() => handleAnswer(i)}
                      disabled={selectedAnswer !== null}
                      className={`w-full text-left px-5 py-4 rounded-xl border transition-all flex items-center gap-3 ${
                        showFeedback
                          ? isCorrect
                            ? "bg-green-50 border-green-300 text-green-800"
                            : isSelected
                            ? "bg-red-50 border-red-300 text-red-800"
                            : "bg-white border-[#2B2B2B]/5 text-[#2B2B2B]/40"
                          : "bg-white border-[#2B2B2B]/10 text-[#2B2B2B] hover:border-[#69B076]/40 hover:bg-[#69B076]/5"
                      }`}
                    >
                      <span className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold shrink-0 ${
                        showFeedback
                          ? isCorrect
                            ? "bg-green-200 text-green-800"
                            : isSelected
                            ? "bg-red-200 text-red-800"
                            : "bg-[#2B2B2B]/5 text-[#2B2B2B]/30"
                          : "bg-[#2B2B2B]/5 text-[#2B2B2B]/50"
                      }`} style={{ fontFamily: "'DM Sans', sans-serif" }}>
                        {showFeedback && isCorrect ? <Check className="w-4 h-4" /> : showFeedback && isSelected ? <X className="w-4 h-4" /> : String.fromCharCode(65 + i)}
                      </span>
                      <span className="text-sm">{opt}</span>
                    </button>
                  );
                })}
              </div>

              {selectedAnswer !== null && (
                <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
                  <div className={`rounded-xl p-4 mb-4 ${
                    selectedAnswer === question.correctIndex ? "bg-green-50 border border-green-200" : "bg-amber-50 border border-amber-200"
                  }`}>
                    <p className="text-sm font-medium mb-1">
                      {selectedAnswer === question.correctIndex ? "✅ 正解！" : "❌ 不正解"}
                    </p>
                    <p className="text-sm text-[#2B2B2B]/60">{question.explanation}</p>
                  </div>
                  <button
                    onClick={nextQuestion}
                    className="w-full py-3 rounded-xl bg-[#69B076] text-white font-medium hover:bg-[#5A9A66] transition-all"
                  >
                    {currentQ < QUESTIONS_PER_LEVEL - 1 ? "次の問題へ →" : "結果を見る"}
                  </button>
                </motion.div>
              )}
            </motion.div>
          </div>
        ) : null}
      </div>
    </section>
  );
}

// ===== Footer =====
function Footer() {
  return (
    <footer className="bg-[#2B2B2B] py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <p className="text-white/30 text-sm mb-2" style={{ fontFamily: "'Zen Maru Gothic', sans-serif" }}>
          🍺 ホップ栽培ガイド 千葉県北部版
        </p>
        <p className="text-white/20 text-xs">
          千葉県北部でのホップ栽培とクラフトビール醸造のための総合ガイド
        </p>
        <div className="section-divider mt-8 mb-4" />
        <p className="text-white/15 text-xs" style={{ fontFamily: "'DM Sans', sans-serif" }}>
          © 2026 Hop Growing Guide — Northern Chiba Edition
        </p>
      </div>
    </footer>
  );
}

// ===== Main Page =====
export default function Home() {
  return (
    <div className="min-h-screen">
      <Navigation />
      <HeroSection />
      <div className="section-divider" />
      <HopTypesSection />
      <BeerStylesSection />
      <BrewingSection />
      <ChibaSection />
      <HopBeerRelationship />
      <QuizSection />
      <Footer />
    </div>
  );
}
